import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Observable, Subscribable } from 'rxjs';
import { ProductService } from '../services/product.service';
import { product } from '../models/product';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
isHandset$: Observable<unknown> | Subscribable<unknown> | Promise<unknown> | undefined;

public searchTerm:string ='';

  constructor(private productservice:ProductService) {}

search(event:any){
  this.searchTerm=(event.target as HTMLInputElement).value;
  console.log(this.searchTerm);
  this.productservice.search.next(this.searchTerm);
  }

}
