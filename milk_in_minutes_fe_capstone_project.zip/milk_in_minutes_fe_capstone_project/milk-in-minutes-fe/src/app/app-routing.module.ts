import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductsviewComponent } from './productsview/productsview.component';
import { CartPageComponent } from './cart-page/cart-page.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [

  { path:'viewallproducts', component:ProductsviewComponent },
  { path: 'cart', component: CartPageComponent },
  { path: 'products', component: ProductsviewComponent },
  { path: 'cart-page', component: CartPageComponent },
  { path: 'products-view', component: ProductsviewComponent },
  { path: 'productsview', component: ProductsviewComponent },
  { path: '', redirectTo: '/productsview', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'registration', component: RegisterComponent },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
