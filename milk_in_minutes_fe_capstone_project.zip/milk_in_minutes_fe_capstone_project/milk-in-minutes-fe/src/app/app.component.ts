import { Component, ViewChild } from '@angular/core';
import { ProductsviewComponent } from './productsview/productsview.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'milk-in-minutes-fe';
}
