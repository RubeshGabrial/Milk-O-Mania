import { Component, Input, OnInit } from '@angular/core';
import { product } from '../models/product';
import { MatMenuPanel } from '@angular/material/menu';
import { ProductService } from '../services/product.service';
import { __values } from 'tslib';
import { CartService } from '../services/cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productsview',
  templateUrl: './productsview.component.html',
  styleUrl: './productsview.component.css'
})
export class ProductsviewComponent implements OnInit{

  productdata:product[]=[];
  menu!: MatMenuPanel<any> | null;
  searchkey:string = "";


  constructor(private productService: ProductService, private cartService: CartService, private router: Router ) {}

  ngOnInit() {
      this.getAllProducts();
      this.productService.search.subscribe((val:any)=>{
      this.searchkey=val;
    })
  }

  getAllProducts() {
    this.productService.getProducts().subscribe((data: product[]) => {
        this.productdata = data;
        console.log("I am get-all-products in productsview component");
      },

      
      (error: any) => {
        console.error('Error fetching data: ', error);
      }
    );
  }

  addProductToCart(index: number) {
    const productToAdd = this.productdata[index];
    this.cartService.addToCart(productToAdd);
  }

  goToCartPage() {
    this.router.navigate(['/cart-page']);
  }

  
}





