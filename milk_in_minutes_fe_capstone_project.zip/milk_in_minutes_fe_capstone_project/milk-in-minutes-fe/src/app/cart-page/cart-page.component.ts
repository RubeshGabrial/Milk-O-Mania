import { Component, OnDestroy, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
import { product } from '../models/product';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrl: './cart-page.component.css'
})
export class CartPageComponent implements OnInit {

  public items: product[] = [];

// items: any[] = []; // Replace 'any' with your actual item type  
  cartItems: never[] | undefined;

  constructor(private cartService: CartService) {
    this.cartService.cartItems$.subscribe((items) => {
      this.items = items;
    });
  }

  ngOnInit() {
    this.cartService.cartItems$.subscribe(items => {
      this.items = items;
    });
  }


  fetchCartItems(): void {
    this.cartService.getCartItems().subscribe(items => {
      this.items = items;
      console.log("I am fetchCartItems in cart-page component");
    });
  }

  getPhotoUrl(item: product): string {
    return `../../assets/${item.Id}.png`;
  }

  incrementQuantity(index: number): void {
    const item = this.items[index];
    if (item && item.Id !== undefined) {
      // Assuming item.Id is the way to access the ID, and item.quantity holds the current quantity
      const newQuantity = item.quantity + 1;
      this.cartService.updateQuantity(item.Id, newQuantity).subscribe({
        next: () => {
          // Optionally, directly update the local item's quantity
          // if the backend doesn't automatically push changes to all clients
          item.quantity = newQuantity;
          // Or call this.refreshCartItems() if you have such a method to reload items from the backend
        },
        error: (error: any) => console.error('Error updating product quantity', error),
      });
    }
  }

  decrementQuantity(index: number): void {
    const item = this.items[index];
    // Assuming you want to decrement the quantity of the item
    if (item.quantity > 0) {
      item.quantity -= 1;
    }
    // Add any additional logic you need to update the quantity in the backend
  }

  removeItem(index: number): void {
    // Ensure the correct property name for ID as expected by your backend
    const itemId = this.items[index].Id; // Change 'Id' to 'id' if necessary
    this.cartService.removeItem(itemId).subscribe({
      next: () => {
        console.log(`Item with ID ${itemId} removed successfully`);
        this.items.splice(index, 1);
      },
      error: (error) => console.error('Error removing item', error)
    });
  }

updateQuantity(index: number, newQuantity: string): void {
  const quantity = parseInt(newQuantity, 10);
  if (!isNaN(quantity)) {
    this.items[index].quantity = quantity;
    // Add any additional logic for backend update
  }
}

  proceedToCheckout(): void {
    // Implement the logic to proceed to checkout
  }


  // Starts a new subscription for clearing the cart
  clearCartItems() {
    this.cartService.clearCart().subscribe({
      next: () => {
        // Correctly reset the items to reflect the cleared cart
        this.items = [];
        console.log('Cart cleared successfully');
        // Update the view to reflect the empty cart
        // No need to reset this.cartItems as it seems to be unused
      },
      error: (error) => {
        console.error('Error clearing cart:', error);
      }
    });
  }
  

}

