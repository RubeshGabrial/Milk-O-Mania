import { Component } from '@angular/core';
import { User } from '../models/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  constructor() { }

  onSignUp() {
    // Implementation for signing up a user
    // This might include validating the form and sending the data to a backend server
  }
}
