import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { product } from '../models/product';
import { BehaviorSubject, Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private products: product[] = [];

  public search = new BehaviorSubject<string>("");
  
  constructor(private http: HttpClient) { }



  getProducts(): Observable<product[]> {
    return this.http.get<product[]>('http://localhost:3000/products');
  }

  getProductById(Id: number): Observable<product> {
    console.log(`Fetching product by ID: ${Id}`); // Add for debugging
    return this.http.get<product>(`http://localhost:3000/products/${Id}`);
  }
}
