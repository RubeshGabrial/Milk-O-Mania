import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, tap, throwError } from 'rxjs';
import { product } from '../models/product';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cartItemsSubject = new BehaviorSubject<product[]>([]);
  public cartItems$ = this.cartItemsSubject.asObservable();
  private cartUrl = 'http://localhost:3000/cart-items';
  cartItems: { Id: number; }[] = [];

  constructor(private http: HttpClient) { }

  addToCart(product: product) {
    console.log("Adding to cart:", product);
    this.http.post<product>(`${this.cartUrl}`, product).subscribe({
      next: (newProduct) => {
        console.log('Added to cart', newProduct);
        this.refreshCartItems();
      },
      error: (error) => console.error('Error adding product to cart', error),
    });
  }

  getCartItems(): Observable<product[]> {
    return this.http.get<product[]>(this.cartUrl);
  }

  removeItem(itemId: number): Observable<any> {
    return this.http.delete(`${this.cartUrl}/${itemId}`).pipe(
      tap(() => this.refreshCartItems()),
      catchError(error => {
        console.error('Error removing item from cart', error);
        return throwError(() => new Error('Error removing item from cart'));
      })
    );
  }

updateQuantity(itemId: number, quantity: number): Observable<any> {
  const item = { quantity }; // Prepare the payload
  return this.http.patch<any>(`${this.cartUrl}/${itemId}`, item);
  // No .subscribe() here, as you should subscribe to the Observable where the method is called
}

clearCart(): Observable<any> {
  // Make a DELETE request to the cart-items endpoint to clear all items
  return this.http.delete(this.cartUrl);
}

private refreshCartItems() {
  this.getCartItems().subscribe(
    cartItems => {
      this.cartItemsSubject.next(cartItems);
      console.log('Cart items refreshed', cartItems);
    },
    error => {
      console.error('Error refreshing cart items', error);
    }
  );
}



}