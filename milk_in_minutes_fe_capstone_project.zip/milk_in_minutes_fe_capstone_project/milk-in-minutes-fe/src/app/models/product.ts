export type product = {
type: any;
size: any;
  quantity: number;
  Id: number;
  title: string;
  price: number;
  brand:string;
  Type:string;
  Size: string;

};
