import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-7AEZFTVQ.js";
import "./chunk-BQBHBMQQ.js";
import "./chunk-QGUGPP4A.js";
import "./chunk-TOO7HMBJ.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-F3U2E253.js";
import "./chunk-23LPRKUQ.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
